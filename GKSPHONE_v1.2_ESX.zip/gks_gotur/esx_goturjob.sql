INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_gotur', 'Götür', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_gotur', 'Götür', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('gotur', 'Götür')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('gotur',0,'recrue','Recrue',12,'{}','{}'),
	('gotur',1,'boss','Patron',0,'{}','{}')
;
