Locales['en'] = {
  ['gotur_time']              = 'Time Left: Order forecast time',
  ['gotur_cancel']            = 'canceled the order',
  ['gotur_productbuy']        = ' Order arrived',
  ['gotur_offline']           = 'The shop is closed, try again later',
  ['gotur_nomoney']           = 'you dont have enough money',
  ['gotur_cancelorder']       = 'The persons order has been canceled because it did not arrive.',
  ['gotur_refund']            = 'Your money has been refunded because your order did not arrive on time.',
  ['gotur_orderway']          = 'Order is on its way ',
  ['gotur_orderdelivered']    = 'Your order has been delivered',
  ['gotur_map']               = 'The order location has been added to the map and you must deliver the order within ',
  ['gotur_itemadd']           = '~r~You cannot add more items than you have',
  ['gotur_itemsell']           = '~r~You cant sell more than you own',
}
