var config = { 
    license:"",
    discordname:""
}